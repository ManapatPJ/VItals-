package com.example.healthmonitoring;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;

import android.os.AsyncTask;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.loopj.android.http.HttpGet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Random;

import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.client.ClientProtocolException;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private RequestQueue mQueue;
    String URL = "https://api.thingspeak.com/channels/733323/feeds.json?api_key=A7U345D8V1DG1MAM&results=100";

    private EditText fname,lname,pulse_rate,temp,bp,respiration, text_location;
    private int REQUEST_CODE = 1;
    //btn_send_to_server.OnClickListener(this)


    double longitude = 0, latitude = 0;
    Location location;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //initializing Buttons
        fname = findViewById(R.id.first_name);
        lname = findViewById(R.id.last_name);
        //initializing Edittexts
        pulse_rate = findViewById(R.id.txt_pulse_rate);
        temp = findViewById(R.id.txt_temperature);
        bp = findViewById(R.id.txt_bp);
        respiration = findViewById(R.id.txt_respiration);
        text_location = findViewById(R.id.txt_location);







        //Checking location permission on create
        int permissionCheck = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        if(permissionCheck != PackageManager.PERMISSION_GRANTED) {
            // ask permissions here using below code
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
        }
        else
        {
            //Location setting
            LocationManager lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
            Criteria crit = new Criteria();
            crit.setAccuracy(Criteria.ACCURACY_FINE);
            String provider = lm.getBestProvider(crit, true);
            Location location = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (location != null){
                longitude = location.getLongitude();
                latitude = location.getLatitude();
            }
        }




        //onclicklistener for btn_send_to_server
        Button btn_send_to_server= findViewById(R.id.btn_send_to_server);
        btn_send_to_server.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // startActivity(new Intent(MainActivity.this,StandingsActivity.class));


                //Send data to server

                String last = lname.getText().toString();
                String first = fname.getText().toString();


                if((!last.equals("")) && (!first.equals(""))){

                    String tmp = temp.getText().toString();
                    String pulse = pulse_rate.getText().toString();
                    String bpressure = bp.getText().toString();
                    String resp = respiration.getText().toString();

                    if((!tmp.equals("")) && (!pulse.equals(""))  && (!bpressure.equals("")) && (!resp.equals(""))){
                        Toast toast=Toast.makeText(getApplicationContext(),"Sending Data.."  +  getLocation(),Toast.LENGTH_SHORT);
                        // toast.setMargin(50,50);
                        toast.show();
                        URL = "https://api.thingspeak.com/update?api_key=8Y7R8TOMTB93P4CA&field1=" + first + "&field2=" + last + "&field3=" + randomize(30, 60) + "&field4=" + randomize(1, 100) + "&field5=" + randomize(1, 100) + "&field6=" + randomize(1, 100) + "&field7=" + randomize(14, 15) + "/" + randomize(121, 122) + "&field8=" + "QualiMed";
                        new FetchDataTask().execute(URL);
                        text_location.setText(getLocation2Digits());
                    }
                    else
                    {
                        Toast toast=Toast.makeText(getApplicationContext(),"Please generate data.",Toast.LENGTH_SHORT);
                        // toast.setMargin(50,50);
                        toast.show();
                    }

                }
                else
                {
                    Toast toast=Toast.makeText(getApplicationContext(),"Fill up Name section correctly.",Toast.LENGTH_SHORT);
                    // toast.setMargin(50,50);
                    toast.show();

                }

            }
        });


        //onclick listener for btn_about
        Button btn_about = findViewById(R.id.btn_about);
        btn_about.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // startActivity(new Intent(MainActivity.this,StandingsActivity.class));
                //Create new activity showing the project and developers
                Toast toast=Toast.makeText(getApplicationContext(),"ABOUT",Toast.LENGTH_SHORT);
                // toast.setMargin(50,50);
                toast.show();
                text_location.setText(getLocation2Digits());
            }
        });

        Button btn_connect = findViewById(R.id.btn_connect);
        btn_connect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // startActivity(new Intent(MainActivity.this,StandingsActivity.class));
                Toast toast=Toast.makeText(getApplicationContext(),"Connect",Toast.LENGTH_SHORT);
                // toast.setMargin(50,50);
                toast.show();
            }
        });




        //Onclick listener for btn_generate
        Button btn_generate_data = findViewById(R.id.btn_generate_data);
        btn_generate_data.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // startActivity(new Intent(MainActivity.this,StandingsActivity.class));
                //Get values from arduino bluetooth.
                //Temporary use generate random numbers to and set edittext values
                Toast toast=Toast.makeText(getApplicationContext(),"Generating Data...",Toast.LENGTH_SHORT);
                // toast.setMargin(50,50);
                toast.show();
                temp.setText("" + randomize(30,37));
                pulse_rate.setText("" + randomize(40,60));
                bp.setText("" + randomize(100,160) + "/" + randomize(60,100));
                respiration.setText("" + randomize(30,70));

                temp.setTextColor(Color.WHITE);
                pulse_rate.setTextColor(Color.WHITE);
                bp.setTextColor(Color.WHITE);
                respiration.setTextColor(Color.WHITE);


            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(MainActivity.this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    public Integer randomize(int min,int max){

        final int random = new Random().nextInt((max - min) + 1) + min;

        return random;
    }

    public String getLocation() {
        int permissionCheck = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        if(permissionCheck != PackageManager.PERMISSION_GRANTED) {
            // ask permissions here using below code
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
        }
        LocationManager lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        location = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        if (location != null){
            longitude = location.getLongitude();
            latitude = location.getLatitude();
        }
            return ("" + longitude + "/" + latitude);

    }

    public String getLocation2Digits() {
        int permissionCheck = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        if(permissionCheck != PackageManager.PERMISSION_GRANTED) {
            // ask permissions here using below code
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
        }

        LocationManager lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        location = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        if (location != null){
            longitude = location.getLongitude();
            latitude = location.getLatitude();
        }

        return ("" + String.format("%.5f",longitude) + "/" + String.format("%.5f",latitude));

    }




    @Override
    public void onClick(View v) {

        //Your Logic
    }

    private class FetchDataTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {

            InputStream inputStream = null;
            String result= null;
            HttpClient client = new DefaultHttpClient();
            HttpGet httpGet = new HttpGet(params[0]);

            try {

                HttpResponse response = client.execute(httpGet);
                inputStream = response.getEntity().getContent();

                // convert inputstream to string
                if(inputStream != null){
                    result = convertInputStreamToString(inputStream);
                    Log.i("App", "Data received:" +result);

                }
                else
                    result = "Failed to fetch data";

                Log.d("JSON:",result);

                return result;

            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String dataFetched) {
            //parse the JSON data and then display
            parseJSON(dataFetched);
        }


        private String convertInputStreamToString(InputStream inputStream) throws IOException{
            BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
            String line = "";
            String result = "";
            while((line = bufferedReader.readLine()) != null)
                result += line;

            inputStream.close();
            return result;

        }

        private void parseJSON(String data){

            try{
                JSONArray jsonMainNode = new JSONArray(data);

                int jsonArrLength = jsonMainNode.length();

                for(int i=0; i < jsonArrLength; i++) {
                    JSONObject jsonChildNode = jsonMainNode.getJSONObject(i);
                    String postTitle = jsonChildNode.getString("feed");
                    Log.d("JSON:",postTitle);

                   // tutorialList.add(postTitle);
                }

                // Get ListView object from xml
                //listView = (ListView) findViewById(R.id.list);

                // Define a new Adapter
               // ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, android.R.id.text1, tutorialList);

                // Assign adapter to ListView
                //listView.setAdapter(adapter);

            }catch(Exception e){
                Log.i("App", "Error parsing data" +e.getMessage());

            }
        }
    }
}


